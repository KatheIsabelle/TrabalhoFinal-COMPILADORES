package ast;

//• classe CReadInput: representa o comando para ler da entrada padrão. Possuí 1 atributo
//var que é a variável onde será atribuido o valor lido
import java.util.*;
import java.io.*;

public class CReadInput extends Comando{
	public int linha;
	public String var;
	
	
	public CReadInput(int linha,String var)
	{
	  this.linha = linha;
	  this.var = var;
	} 

	public void gerarCodigo(PrintWriter out) {
        out.println(var + " = new java.util.Scanner(System.in).nextLine();");
    }

}
