package ast;

//classe VarDecl: representa uma declaração de variável. Possuí dois atributos type (o
//tipo da variável) e var (a variável sendo declarada)

import java.util.*;
import java.io.*;

public class VarDecl {
    public String type;
    public String var;

    public VarDecl(String type, String var) {
        this.type = type;
        this.var = var;
    }

    public void gerarCodigo(PrintWriter out) {
        out.println("    " + type + " " + var + ";");
    }
}
