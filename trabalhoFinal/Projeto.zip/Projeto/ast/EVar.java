package ast;

//classe EVar: representa uma expressão que é uma variável. Possuí 1 atributo var, a
//variável

import ast.Exp;
import java.util.*;
import java.io.*;

public class EVar extends Exp{
	public String var;
	
	
	public EVar(String var)
	{
	  this.var = var;
	  
	} 

	public void gerarCodigo(PrintWriter out) {
        out.print(var);
    }

}
