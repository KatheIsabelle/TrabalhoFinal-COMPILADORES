package ast;

// classe EOpExp: representa uma expressão que é uma operação usando um operador.
// Possui 3 atributos: op (o operador), arg1 (o primeiro argumento) e arg2 (o segundo argumento)
import java.util.*;
import java.io.*;

public class EOpExp extends Exp {
    public String op;
    public Exp arg1;
    public Exp arg2;

    // Construtor
    public EOpExp(String op, Exp arg1, Exp arg2) {
        this.op = op;
        this.arg1 = arg1;
        this.arg2 = arg2;
    }

    public void gerarCodigo(PrintWriter out) {
        out.print("(");
        arg1.gerarCodigo(out);
        out.print(" " + op + " ");
        arg2.gerarCodigo(out);
        out.print(")");
    }
}
