package ast;

import java.io.PrintWriter;
import java.util.List;

public class GeradorCodigo {
    private PrintWriter out;

    public GeradorCodigo(PrintWriter out) {
        this.out = out;
    }

    public void geraMain(Main main) {
        // Declarar variáveis
        for (VarDecl v : main.getVars()) {
            out.println("        " + v.getTipo() + " " + v.getNome() + ";");
        }

        // Gerar comandos
        for (Comando c : main.getComandos()) {
            geraComando(c, "        ");
        }
    }

    public void geraFunc(Fun f) {
        out.print("    public static " + f.getTipo() + " " + f.getNome() + "(");
        List<ParamFormalFun> params = f.getParams();
        for (int i = 0; i < params.size(); i++) {
            ParamFormalFun p = params.get(i);
            out.print(p.getTipo() + " " + p.getNome());
            if (i < params.size() - 1) out.print(", ");
        }
        out.println(") {");

        for (VarDecl v : f.getVars()) {
            out.println("        " + v.getTipo() + " " + v.getNome() + ";");
        }

        for (Comando c : f.getCorpo()) {
            geraComando(c, "        ");
        }

        out.println("    }");
    }

    public void geraComando(Comando c, String indent) {
        if (c instanceof CAtribuicao) {
            CAtribuicao a = (CAtribuicao) c;
            out.println(indent + a.getVar() + " = " + geraExp(a.getExp()) + ";");

        } else if (c instanceof CIf) {
            CIf ci = (CIf) c;
            out.println(indent + "if (" + geraExp(ci.getCondicao()) + ") {");
            for (Comando cmd : ci.getBloco()) {
                geraComando(cmd, indent + "    ");
            }
            out.println(indent + "}");

        } else if (c instanceof CWhile) {
            CWhile cw = (CWhile) c;
            out.println(indent + "while (" + geraExp(cw.getCondicao()) + ") {");
            for (Comando cmd : cw.getBloco()) {
                geraComando(cmd, indent + "    ");
            }
            out.println(indent + "}");

        } else if (c instanceof CPrint) {
            CPrint p = (CPrint) c;
            out.println(indent + "System.out.println(" + geraExp(p.getExp()) + ");");

        } else if (c instanceof CReturn) {
            CReturn r = (CReturn) c;
            out.println(indent + "return " + geraExp(r.getExp()) + ";");

        } else if (c instanceof CReadInput) {
            CReadInput r = (CReadInput) c;
            out.println(indent + r.getVar() + " = new java.util.Scanner(System.in).nextFloat();");

        } else if (c instanceof CChamadaFun) {
            CChamadaFun ch = (CChamadaFun) c;
            out.println(indent + geraExp(new EChamadaFun(ch.getNome(), ch.getArgs())) + ";");

        } else {
            out.println(indent + "// comando não implementado");
        }
    }

    public String geraExp(Exp e) {
        if (e instanceof EVar) {
            return ((EVar) e).getNome();

        } else if (e instanceof EFloat) {
            return Float.toString(((EFloat) e).getValor());

        } else if (e instanceof ETrue) {
            return "true";

        } else if (e instanceof EFalse) {
            return "false";

        } else if (e instanceof EOpExp) {
            EOpExp op = (EOpExp) e;
            return "(" + geraExp(op.getEsq()) + " " + op.getOperador() + " " + geraExp(op.getDir()) + ")";

        } else if (e instanceof EChamadaFun) {
            EChamadaFun ch = (EChamadaFun) e;
            StringBuilder sb = new StringBuilder(ch.getNome() + "(");
            List<Exp> args = ch.getArgs();
            for (int i = 0; i < args.size(); i++) {
                sb.append(geraExp(args.get(i)));
                if (i < args.size() - 1) sb.append(", ");
            }
            sb.append(")");
            return sb.toString();
        }

        return "/* exp não implementada */";
    }
}
