package ast;

import java.util.ArrayList;
//classe Fun: representa uma função. Possuí 5 atributos: nome (o nome da função), params
//(um array list com os parâmetros declarados para a função), retorno (o tipo de retorno
//da função), vars (as variáveis declaradas no corpo da função) e body (o corpo da função)

import ast.ParamFormalFun;
import ast.VarDecl;
import ast.Comando;
import java.util.*;
import java.io.*;


public class Fun{
	public String nome;
	public ArrayList<ParamFormalFun> params;
	public String retorno;
	public ArrayList<VarDecl> vars;
	public ArrayList<Comando> body;
	
	public Fun(String nome,ArrayList<ParamFormalFun> params, String retorno,ArrayList<VarDecl> vars,ArrayList<Comando> body)
	{
		this.nome = nome;
		this.params = params;
		this.retorno = retorno;
		this.vars = vars;
		this.body = body;
	}

	public void gerarCodigo(PrintWriter out) {
		out.print("public " + retorno + " " + nome + "(");
		for (int i = 0; i < params.size(); i++) {
			if (i > 0) out.print(", ");
			params.get(i).gerarCodigo(out);
		}
		out.println(") {");
		
		for (VarDecl var : vars) {
			var.gerarCodigo(out);
		}
		
		for (Comando cmd : body) {
			cmd.gerarCodigo(out);
		}
		
		out.println("}");
	}
}
