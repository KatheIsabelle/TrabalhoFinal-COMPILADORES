package ast;

//classe Prog: representa um programa. Possuí dois atributos: main (o programa principal)
//e fun (um array de definições de funções)

import java.util.*;
import java.io.*;

public class Prog {
    public Main main;
    public ArrayList<Fun> fun;

    public Prog(Main main, ArrayList<Fun> fun) {
        this.main = main;
        this.fun = fun;
    }

    public void gerarCodigo(PrintWriter out) {
        out.println("public class ProgramaGerado {");
        out.println("    public static void main(String[] args) {");
        main.gerarCodigo(out);
        out.println("    }");
        for (Fun f : funs) {
            f.gerarCodigo(out);
        }
        out.println("}");
    }
}




