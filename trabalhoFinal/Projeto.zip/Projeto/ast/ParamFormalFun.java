package ast;

//classe ParamFormalFun: contém a declaração de 1 parâmetro de uma função. Possuí 2
//atributos var (o nome da variável) e type (o tipo da variável)

import java.util.*;
import java.io.*;

public class ParamFormalFun{
   public String type;
   public String var;
   
   public ParamFormalFun(String type,String var){
   	this.type = type;
   	this.var = var;
   }

   public void gerarCodigo(PrintWriter out) {
      out.print(type + " " + var);
   }
}
