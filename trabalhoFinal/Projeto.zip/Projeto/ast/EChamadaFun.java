package ast;

import java.util.*;
import java.io.*;

//classe EChamadaFun: representa uma expressão que é uma chamada de função. Possuí
//dois atributos: fun (a função sendo chamada) e args (que são os argumentos sendo
//passados para função)

public class EChamadaFun extends Exp{
	public String fun;
	public ArrayList<Exp> args;
	
	public EChamadaFun(String fun, ArrayList<Exp> args)
	{
	  this.fun = fun;
	  this.args = args;
	} 

	public void gerarCodigo(PrintWriter out) {
        out.print(fun + "(");
        for (int i = 0; i < args.size(); i++) {
            args.get(i).gerarCodigo(out);
            if (i < args.size() - 1) {
                out.print(", ");
            }
        }
        out.println(");");
    }

}
