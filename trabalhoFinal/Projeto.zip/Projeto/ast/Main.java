package ast;

//classe Main: representa o main de um programa. Possuí dois atributos vars (um array
//de declaração de variáveis) e coms (um array de comandos)

import java.util.*;
import java.io.*;

public class Main {

    public ArrayList<VarDecl> vars;
    public ArrayList<Comando> coms;

    public Main(ArrayList<VarDecl> vars, ArrayList<Comando> coms) {
        this.vars = vars;
        this.coms = coms;
    }

    public void gerarCodigo(PrintWriter out) {
    for (VarDecl var : vars) {
        var.gerarCodigo(out);
    }
    for (Comando cmd : coms) {
        cmd.gerarCodigo(out);
    }
}
