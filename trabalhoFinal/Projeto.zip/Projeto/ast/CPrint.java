package ast;


import java.util.*;
import java.io.*;
//classe CPrint: representa o comando de imprimir na saída padrão. Possuí 1 atributo
//exp, que é a expressão a ser imprimida na tela

public class CPrint extends Comando{
	public int linha;
	public Exp exp;
	
	
	public CPrint(int linha,Exp exp)
	{
	  this.linha = linha;
	  this.exp = exp;
	  
	} 

	public void gerarCodigo(PrintWriter out) {
    	out.print("System.out.println(");
        exp.gerarCodigo(out);
        out.println(");");
    }

}
