package ast;

import java.util.*;
import java.io.*;
//classe EFalse: representa uma expressão que é o valor false

public class EFalse extends Exp{
	
	public EFalse()
	{
	  super();
	  
	} 

	public void gerarCodigo(PrintWriter out) {
		out.print("false");
	}

}
