package ast;

//classe Exp: superclasse de todas as expressões
import java.util.*;
import java.io.*;


public class Exp{

    public abstract void gerarCodigo(PrintWriter out);
}
