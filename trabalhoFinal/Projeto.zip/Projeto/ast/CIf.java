package ast;

//classe CIf: representa o comando if. Possuí dois atributos: exp (representa a expressão
//booleana) e bloco (um array de comandos representando o bloco do then)

import java.util.*;
import java.io.*;

public class CIf extends Comando{
	public int linha;
	public Exp exp;
	public ArrayList<Comando> bloco;
	
	public CIf(int linha,Exp exp, ArrayList<Comando> bloco)
	{
	  this.linha = linha;
	  this.exp = exp;
	  this.bloco = bloco;
	} 

	public void gerarCodigo(PrintWriter out) {
        out.print("if (");
        exp.gerarCodigo(out);
        out.println(") {");
        for (Comando c : bloco)
            c.gerarCodigo(out);
        out.println("}");
    }

}

