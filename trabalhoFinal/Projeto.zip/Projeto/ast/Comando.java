package ast;

//classe Comando: superclasse de todos os comandos

import java.util.*;
import java.io.*;

public abstract class Comando {
    public abstract void gerarCodigo(PrintWriter out);
}
