package ast;

import java.util.*;
import java.io.*;

//classe CChamadaFun: representa uma chamada de função. Possuí dois atributos: fun (a
//função sendo chamada) e args (os argumentos a serem passados para a função)

public class CChamadaFun extends Comando{
	public int linha;
	public String fun;
	public ArrayList<Exp> args;
	
	public CChamadaFun(int linha,String fun, ArrayList<Exp> args)
	{
	  this.linha = linha;
	  this.fun = fun;
	  this.args = args;
	} 
	
    public void gerarCodigo(PrintWriter out) {
        out.print(fun + "(");
        for (int i = 0; i < args.size(); i++) {
            args.get(i).gerarCodigo(out);
            if (i < args.size() - 1) {
                out.print(", ");
            }
        }
        out.println(");");
    }

}
