package ast;
// classe EFloat: representa uma expressão que é um float. Possuí um atributo value que
// é o valor do float

import java.util.*;
import java.io.*;

public class EFloat extends Exp{
	public float value;
	
	
	public EFloat(float value)
	{
	  this.value = value;
	  
	} 

	public void gerarCodigo(PrintWriter out) {
		out.print(value);
	}

}
