package ast;

import java.util.*;
import java.io.*;

//classe CWhile: representa o comando while. Possuí 2 atributos: exp que é a expressão
//booleana do while e bloco que é o bloco a ser executado pelo while (um ArrayList de
//comandos)

public class CWhile extends Comando{
	public int linha;
	public Exp exp;
	public ArrayList<Comando> bloco;
	
	public CWhile(int linha,Exp exp, ArrayList<Comando> bloco)
	{
	  this.linha = linha;
	  this.exp = exp;
	  this.bloco = bloco;
	} 

	public void gerarCodigo(PrintWriter out) {
        out.print("while (");
        exp.gerarCodigo(out);
        out.println(") {");
        for (Comando c : bloco) {
            c.gerarCodigo(out);
        }
        out.println("}");
    }

}
