package ast;

import java.util.*;
import java.io.*;
//classe CReturn: representa o comando return. Possuí 1 atributo exp que é a expressão
//sendo retornada

public class CReturn extends Comando{
	public int linha;
	public Exp exp;
	
	
	public CReturn(int linha,Exp exp)
	{
	  this.linha = linha;
	  this.exp = exp;
	  
	}

	public void gerarCodigo(PrintWriter out) {
        out.print("return ");
        exp.gerarCodigo(out);
        out.println(";");
    }

}
