package ast;
//classe ETrue: representa uma expressão que é o valor true

import java.util.*;
import java.io.*;

public class ETrue extends Exp{
	
	public ETrue()
	{
	  super();
	  
	} 

	public void gerarCodigo(PrintWriter out) {
		out.print("true");
	}

}
